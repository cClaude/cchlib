package cx.ath.choisnet.io;

/**
 *
 */
public interface MyInterface
{
    int getA();
    String getB();
}
