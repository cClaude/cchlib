package cx.ath.choisnet.io;

import java.io.Serializable;

/**
 *
 */
public interface MyInterfaceSerializable extends MyInterface, Serializable
{
}
