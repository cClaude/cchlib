package cx.ath.choisnet.util;

import org.junit.Test;

/**
 *
 */
public class ExternalAppTest
{
    @Test
    public void test1() throws ExternalAppException
    {
        /*
        OutputStream stdout = System.out;
        OutputStream stderr = System.err;
        ExternalApp.execute( getCommand(), stdout, stderr );
        */
    }
/*
    private String getCommand()
    {
        // TODO choice cmd according to OS
        return "ping 127.0.0.1";
    }
*/
}
