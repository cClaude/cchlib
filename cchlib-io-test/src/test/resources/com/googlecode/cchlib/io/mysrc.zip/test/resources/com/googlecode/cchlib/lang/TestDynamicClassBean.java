package com.googlecode.cchlib.lang;

/**
 * Test class to add in class path
 */
public class TestDynamicClassBean
{
    private String value;

    public TestDynamicClassBean()
    {
        // empty
    }

    public String getValue()
    {
        return value;
    }

    public void setValue( String value )
    {
        this.value = value;
    }
}
